import React from 'react'
import './Footer.css';

export const Footer = () => {
    return (
        <footer>
            <span>
                Copyright © Dêrik-online-shop 2023
            </span>
        </footer>
    )
}
